package com.mkurbanov.smsugradyjy;

public interface config {
    String BASE_URL = "http://216.250.11.112:3000/";
    String LOG_TAG = "SMSUgradyjy";
}
