package com.mkurbanov.smsugradyjy.ui.main;

public interface SocketOnErrorListener {
    void onError();
}
